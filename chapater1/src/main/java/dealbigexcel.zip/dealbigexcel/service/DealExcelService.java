package dealbigexcel.service;

/**
 * @author stuminker
 * @version 1.0
 * @project normal
 * @description
 * @date 2023/2/22 22:20:07
 */
public interface DealExcelService {
    public void readBigDataExcel(String path) throws Exception;

}
